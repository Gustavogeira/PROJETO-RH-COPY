## FUNÇAO MENU
### FUNÇÃO INSS( )
    - É um calculo de pagamento automático que ocorre sobre o salário do trabalhador, como forma de contribuição para a previdência, que garante benefícios aos assalariado no futuro.
### FUNÇÃO FÉRIAS( )
    - É um calculo da  antecipação do salário nas férias.
### FUNÇÃO IMPOSTO DE RENDA( )
    - É um calculo mensalmente retido do salário dos brasileiros ou por eles pago com base em outros rendimentos.
### FUNÇAO ADICIONAL NORTUNO( )
    - É um calculo de acréscimo de até 20% na hora trabalhada para todos os colaboradores em jornada noturna.
### FUNÇÃO HORAS EXTRAS( )
    - É um calculo e o pagamento da hora extra será o valor da hora normal + 50% do valor da hora normal de trabalho.
### FUNÇÃO PERICULOSIDADE( )
    - É um calculo que o  benefício irá acrescentar um adicional de 30% sobre o salário-base do colaborador.
### FUNÇAO CONTRIBUIÇÃO FGTS( )
    - É um calculo do  valor será o correspondente a 8%  do salário bruto pago ao trabalhador
### FUNÇÃO MULTA FGTS( )
    - O valor é calculado sobre tudo o que foi depositado na conta do FGTS do trabalhador durante todo o tempo trabalhado.
### FUNÇÃO PIS( )
    - É um calculo para receber o abono, é preciso ter trabalhado ao menos 30 dias com carteira assinada durante o ano-base.
### FUNÇÃO SEGURO DESEMPREGO( )
    -È um benefício que oferece auxílio em dinheiro por um período determinado
### FUNÇÃO VALE TRANSPORTE( )
    -O empregador pode descontar até 6% do salário fixo do empregado.
### FUNÇÃO COMPLETA( )
    -É o resultado geral das somas dos valores descontados e depósitados.
## OPERAÇÕA MENU
### CALCULO INSS( )
    - 1ª faixa salarial: R$ 1.100,00 x 7,5% = R$ 82,50.
      2ª faixa salarial: (R$ 2.203,48 – R$ 1.100,01) x 9% = R$ 99,31.
      3ª faixa salarial: (R$ 3.305,22 – R$ 2.203,49) x 12% = R$ 132,20.
      4ª faixa salarial: (R$ 6.433,57 – R$ 3.305,23) x 14% = R$ 437,96.
### CALCULO FÉRIAS( )
    - Para o cálculo de férias, deve-se levar em conta a remuneração do trabalhador no mês anterior, acrescido de ⅓ do valor do salário.
### CALCULO IMPOSTO DE RENDA( )
    - De R$ 1.903,99 até R$ 2.826,65 7,5% R$ 142,80
      De R$ 2.826,66 até R$ 3.751,05 15% R$ 354,80
      De R$ 3.751,06 até R$ 4.664,68 22,5% R$ 636,13
      Acima de R$ 4.664,68              27,5%    R$ 869,36
### CALCULO ADICIONAL NOTURNO( )
    - Basta dividir o salário-base mensal do colaborador pelas horas contratuais e, depois, multiplicar o valor da hora normal pelo percentual do adicional noturno.
### CALCULO HORAS EXTRAS( )
    -  Basta dividir o salário mensal do empregado pelo número de horas trabalhadas. Multiplique esse valor por 1,5 e terá o valor da hora extra.
### CALCULO PERICULOSIDADE( )
    -  Salário bruto x 0,3 = adicional de periculosidade.
### CALCULO CONTRIBUIÇÃO FGTS( )
    -  O cálculo mensal do FGTS é sempre 8% para a maioria dos trabalhadores, basta multiplicar o salário bruto por 8%.
### CALCULO MULTA FGTS( )
    -  O valor é calculado sobre tudo o que foi depositado na conta do FGTS do trabalhador durante todo o tempo trabalhado
### CALCULO PIS( )
    -  dividir o salário mínimo vigente por 12; multiplicar o resultado pelo número de meses trabalhados.
### CALCULO SEGURO DESEMPREGO( )
    -  Efetuar a média dos 3 últimos salários ;
       Até R$ 1.968,36 multiplica-se salário médio por 0,80 ( 80% ) ;
       De R$ 1.968,37 até R$ 3.280,93 o que exceder a R$ 1.968,36 multiplica-se por 0,50( 50%) e soma-se a R$ 1.574,69 ;
       Acima de R$ 3.280,93 o valor da parcela será de R$ 2.230,97;
### CALCULO VALE TRANSPORTE( )
    -  Tenha em mãos os valores das passagens que serão utilizadas pelo colaborador;
       Multiplique o valor gasto diariamente pela quantidade de dias úteis do mês para descobrir quanto será a quantia mensal;
       Calcule o valor do desconto, mas lembre-se que ele não pode ultrapassar 6% do salário base;
